# frozen_string_literal: true

class CredentialService < Steroids::Connector::InputCredentialService

  DOMAIN_REGEX = /api\.\w+\.insightly\.com\z/i.freeze

  def create(exchanger)
    validate_domain!(require_param!(exchanger[:domain]), regex: DOMAIN_REGEX)
    require_param!(exchanger[:api_key])

    super
  end

  def verify!(environment = self.environment)
    # Quick call to the API endpoint, to check if credential actually works.
    transport(environment: environment).get(path: '/Users/Me')
  end

end
