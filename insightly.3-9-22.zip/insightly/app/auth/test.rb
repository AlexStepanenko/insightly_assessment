# frozen_string_literal: true

class CredentialService::Test < Steroids::Test::Suite

  def run
    # r(:test_verify)
    # r(:test_create_credentials)
  end

end
