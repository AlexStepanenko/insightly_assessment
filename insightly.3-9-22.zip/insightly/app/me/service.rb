# frozen_string_literal: true

module Me
  class Service < Steroids::Connector::MeService

    # Define here me and lock (these are extra task points)

    def me
      transport(environment: environment).get(path: '/Users/Me').tap do |data|
        data[:instance_url] = instance_url
        data[:human] = "#{data[:FIRST_NAME]} #{data[:LAST_NAME]} (Domain: #{instance_url})"

        data
      end
    end

    def lock
      { keys: [instance_url] }
    end

    private

    def instance_url
      [environment.credential[:domain], environment.credential[:path]].
        compact.join('/')
    end

  end
end
