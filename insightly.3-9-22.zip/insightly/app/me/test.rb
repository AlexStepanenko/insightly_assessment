# frozen_string_literal: true

module Me
  class Test < Steroids::Test::Suite

    def run
      # r(:test_me)
      # r(:test_me_lock)
    end

  end
end
