# frozen_string_literal: true

require 'steroids/connector/auth/input'
require 'steroids/connector/subscriptions/letmeknow'

class Metadata < Steroids::Connector::Metadata

  def name
    'Insightly'
  end

  def authentication
    Steroids::Connector::Metadata::Authentication.new(:input)
  end

end
