# frozen_string_literal: true

require 'steroids/connector/http'

class Default < Steroids::Connector::Http::JsonTransport


  # Define here root API path and proper requests authorization
  # These are required task points.
  def root(options)
    "https://#{environment.credential.fetch(:domain)}/v3.1"
  end

  def basic_auth(request, options)
    { user: environment.credential.fetch(:api_key) }
  end

  # Define error method (this is extra points task)
end
