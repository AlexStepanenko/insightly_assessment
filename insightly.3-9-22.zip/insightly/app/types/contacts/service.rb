# frozen_string_literal: true


module Contacts
  class Service < Steroids::Connector::TypeService
    # Include here proper Steroids::Connector::Paging:: module
    # Define list_page, find, create, update, destroy methods to work with Insightly API endpoints for contacts
    # Both are required task points
    include Steroids::Connector::Paging::ReverseChronologicalByLastModified

    def list_page(offset:, limit:, since: nil)
      params = {
        updated_after_utc: since,
        skip: offset,
        top: limit
      }

      transport.get(path: '/Contacts', params: params)
    end

    def find(id)
      transport.get(path: "/Contacts/#{id}")
    end

    def create(contact)
      transport.post(path: '/Contacts', body: contact)
    end

    def update(id, changeset)
      transport.put(path: '/Contacts', body: { CONTACT_ID: id }.merge(changeset))
    end

    def destroy(id)
      transport.delete(path: "/Contacts/#{id}")
    end

    private

    def page_size
      1..50
    end

    DATETIME_FORMAT = '%F %T'

    def get_last_modified_datetime(resource_data)
      DateTime.strptime(resource_data[:DATE_UPDATED_UTC], DATETIME_FORMAT)
    end
  end
end
