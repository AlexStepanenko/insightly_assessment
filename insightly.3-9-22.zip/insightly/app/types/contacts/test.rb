# frozen_string_literal: true

module Contacts
  class Test < Steroids::Test::Suite

    def vcr_match_requests_on
      uri = VCR.request_matchers.uri_without_param(:updated_after_utc)
      [:method, uri, :body_raw_or_as_json]
    end

    def run
      # clear(concurrency: 1)
      # seed(1..110, concurrency: 1)

      # r(:test_list_all)
      with_sleep_period 20.seconds do
        # r(:test_list_creations, allowed_overlap: 0)
        # r(:test_list_modifications, allowed_overlap: 0)
        #
        # r(:test_poll_creations, expected_triggers: 2)
        # r(:test_poll_modifications, expected_triggers: 2)
      end

    end

    def test_list_all(method: :gen)
      resources = gen_range(seed_refs, method: method)

      # Contacts associated with users and admins can't be deleted
      resources.unshift(gen('Account owner'))

      check_list_all(expect: resources)
    end

    def test_find_not_found
      check_find_not_found(id: '1')
    end



    private

    def gen(r = 'test', attrs = {})
      resource(
        {
          FIRST_NAME: "TestContact #{r}"
        }.merge(attrs)
      )
    end

    module SleepALittle

      def create(*args)
        super.tap { sleep(@sleep || 0) }
      end

      def modify(*args)
        super.tap { sleep(@sleep || 0) }
      end

      def destroy(*args)
        super.tap { sleep(@sleep || 0) }
      end

      def create_returning_id(*args)
        super.tap { sleep(@sleep || 0) }
      end

      def modify_returning_nothing(*args)
        super.tap { sleep(@sleep || 0) }
      end

      def with_sleep_period(sleep)
        @sleep = sleep
        yield
      ensure
        @sleep = nil
      end

    end

    include SleepALittle

  end
end
