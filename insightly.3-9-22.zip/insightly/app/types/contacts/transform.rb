# frozen_string_literal: true

module Contacts
  class Transform < Steroids::Connector::Transform

    def transform_in_changeset(resource, changeset)
      changeset
    end
  end
end
